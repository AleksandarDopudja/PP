// generated with ast extension for cup
// version 0.8
// 16/0/2023 13:16:44


package rs.ac.bg.etf.pp1.ast;

public class VarDeclC extends VarDecl {

    private VarD VarD;
    private VarDeclList VarDeclList;

    public VarDeclC (VarD VarD, VarDeclList VarDeclList) {
        this.VarD=VarD;
        if(VarD!=null) VarD.setParent(this);
        this.VarDeclList=VarDeclList;
        if(VarDeclList!=null) VarDeclList.setParent(this);
    }

    public VarD getVarD() {
        return VarD;
    }

    public void setVarD(VarD VarD) {
        this.VarD=VarD;
    }

    public VarDeclList getVarDeclList() {
        return VarDeclList;
    }

    public void setVarDeclList(VarDeclList VarDeclList) {
        this.VarDeclList=VarDeclList;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(VarD!=null) VarD.accept(visitor);
        if(VarDeclList!=null) VarDeclList.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(VarD!=null) VarD.traverseTopDown(visitor);
        if(VarDeclList!=null) VarDeclList.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(VarD!=null) VarD.traverseBottomUp(visitor);
        if(VarDeclList!=null) VarDeclList.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("VarDeclC(\n");

        if(VarD!=null)
            buffer.append(VarD.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(VarDeclList!=null)
            buffer.append(VarDeclList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [VarDeclC]");
        return buffer.toString();
    }
}
