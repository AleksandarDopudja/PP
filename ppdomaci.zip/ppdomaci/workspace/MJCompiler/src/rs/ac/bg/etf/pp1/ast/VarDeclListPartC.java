// generated with ast extension for cup
// version 0.8
// 16/0/2023 13:16:44


package rs.ac.bg.etf.pp1.ast;

public class VarDeclListPartC extends VarDeclListPart {

    private VarDTwo VarDTwo;

    public VarDeclListPartC (VarDTwo VarDTwo) {
        this.VarDTwo=VarDTwo;
        if(VarDTwo!=null) VarDTwo.setParent(this);
    }

    public VarDTwo getVarDTwo() {
        return VarDTwo;
    }

    public void setVarDTwo(VarDTwo VarDTwo) {
        this.VarDTwo=VarDTwo;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(VarDTwo!=null) VarDTwo.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(VarDTwo!=null) VarDTwo.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(VarDTwo!=null) VarDTwo.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("VarDeclListPartC(\n");

        if(VarDTwo!=null)
            buffer.append(VarDTwo.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [VarDeclListPartC]");
        return buffer.toString();
    }
}
