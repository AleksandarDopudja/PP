// generated with ast extension for cup
// version 0.8
// 16/0/2023 13:16:44


package rs.ac.bg.etf.pp1.ast;

public class MethodDeclFPC extends MethodDeclFP {

    private MethodTypeName MethodTypeName;
    private FormPars FormPars;
    private DeclVarOnlyList DeclVarOnlyList;

    public MethodDeclFPC (MethodTypeName MethodTypeName, FormPars FormPars, DeclVarOnlyList DeclVarOnlyList) {
        this.MethodTypeName=MethodTypeName;
        if(MethodTypeName!=null) MethodTypeName.setParent(this);
        this.FormPars=FormPars;
        if(FormPars!=null) FormPars.setParent(this);
        this.DeclVarOnlyList=DeclVarOnlyList;
        if(DeclVarOnlyList!=null) DeclVarOnlyList.setParent(this);
    }

    public MethodTypeName getMethodTypeName() {
        return MethodTypeName;
    }

    public void setMethodTypeName(MethodTypeName MethodTypeName) {
        this.MethodTypeName=MethodTypeName;
    }

    public FormPars getFormPars() {
        return FormPars;
    }

    public void setFormPars(FormPars FormPars) {
        this.FormPars=FormPars;
    }

    public DeclVarOnlyList getDeclVarOnlyList() {
        return DeclVarOnlyList;
    }

    public void setDeclVarOnlyList(DeclVarOnlyList DeclVarOnlyList) {
        this.DeclVarOnlyList=DeclVarOnlyList;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(MethodTypeName!=null) MethodTypeName.accept(visitor);
        if(FormPars!=null) FormPars.accept(visitor);
        if(DeclVarOnlyList!=null) DeclVarOnlyList.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(MethodTypeName!=null) MethodTypeName.traverseTopDown(visitor);
        if(FormPars!=null) FormPars.traverseTopDown(visitor);
        if(DeclVarOnlyList!=null) DeclVarOnlyList.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(MethodTypeName!=null) MethodTypeName.traverseBottomUp(visitor);
        if(FormPars!=null) FormPars.traverseBottomUp(visitor);
        if(DeclVarOnlyList!=null) DeclVarOnlyList.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("MethodDeclFPC(\n");

        if(MethodTypeName!=null)
            buffer.append(MethodTypeName.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(FormPars!=null)
            buffer.append(FormPars.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(DeclVarOnlyList!=null)
            buffer.append(DeclVarOnlyList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [MethodDeclFPC]");
        return buffer.toString();
    }
}
