// generated with ast extension for cup
// version 0.8
// 16/0/2023 13:16:44


package rs.ac.bg.etf.pp1.ast;

public class DesignatorStatementAssign extends DesignatorStatement {

    private DLsquare DLsquare;
    private DesignatorOpt DesignatorOpt;
    private DesignatorOptList DesignatorOptList;
    private Designator Designator;

    public DesignatorStatementAssign (DLsquare DLsquare, DesignatorOpt DesignatorOpt, DesignatorOptList DesignatorOptList, Designator Designator) {
        this.DLsquare=DLsquare;
        if(DLsquare!=null) DLsquare.setParent(this);
        this.DesignatorOpt=DesignatorOpt;
        if(DesignatorOpt!=null) DesignatorOpt.setParent(this);
        this.DesignatorOptList=DesignatorOptList;
        if(DesignatorOptList!=null) DesignatorOptList.setParent(this);
        this.Designator=Designator;
        if(Designator!=null) Designator.setParent(this);
    }

    public DLsquare getDLsquare() {
        return DLsquare;
    }

    public void setDLsquare(DLsquare DLsquare) {
        this.DLsquare=DLsquare;
    }

    public DesignatorOpt getDesignatorOpt() {
        return DesignatorOpt;
    }

    public void setDesignatorOpt(DesignatorOpt DesignatorOpt) {
        this.DesignatorOpt=DesignatorOpt;
    }

    public DesignatorOptList getDesignatorOptList() {
        return DesignatorOptList;
    }

    public void setDesignatorOptList(DesignatorOptList DesignatorOptList) {
        this.DesignatorOptList=DesignatorOptList;
    }

    public Designator getDesignator() {
        return Designator;
    }

    public void setDesignator(Designator Designator) {
        this.Designator=Designator;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(DLsquare!=null) DLsquare.accept(visitor);
        if(DesignatorOpt!=null) DesignatorOpt.accept(visitor);
        if(DesignatorOptList!=null) DesignatorOptList.accept(visitor);
        if(Designator!=null) Designator.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(DLsquare!=null) DLsquare.traverseTopDown(visitor);
        if(DesignatorOpt!=null) DesignatorOpt.traverseTopDown(visitor);
        if(DesignatorOptList!=null) DesignatorOptList.traverseTopDown(visitor);
        if(Designator!=null) Designator.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(DLsquare!=null) DLsquare.traverseBottomUp(visitor);
        if(DesignatorOpt!=null) DesignatorOpt.traverseBottomUp(visitor);
        if(DesignatorOptList!=null) DesignatorOptList.traverseBottomUp(visitor);
        if(Designator!=null) Designator.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("DesignatorStatementAssign(\n");

        if(DLsquare!=null)
            buffer.append(DLsquare.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(DesignatorOpt!=null)
            buffer.append(DesignatorOpt.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(DesignatorOptList!=null)
            buffer.append(DesignatorOptList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(Designator!=null)
            buffer.append(Designator.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [DesignatorStatementAssign]");
        return buffer.toString();
    }
}
