// generated with ast extension for cup
// version 0.8
// 16/0/2023 13:16:44


package rs.ac.bg.etf.pp1.ast;

public abstract class VisitorAdaptor implements Visitor { 

    public void visit(MinusOp MinusOp) { }
    public void visit(Mulop Mulop) { }
    public void visit(VarD VarD) { }
    public void visit(FormalParamDecl FormalParamDecl) { }
    public void visit(MethodeDecl MethodeDecl) { }
    public void visit(DesignatorOpt DesignatorOpt) { }
    public void visit(DesignatorOptList DesignatorOptList) { }
    public void visit(StatementList StatementList) { }
    public void visit(VarDTwo VarDTwo) { }
    public void visit(Addop Addop) { }
    public void visit(Factor Factor) { }
    public void visit(DeclList DeclList) { }
    public void visit(Designator Designator) { }
    public void visit(Term Term) { }
    public void visit(DLsquare DLsquare) { }
    public void visit(DeclVarOnlyList DeclVarOnlyList) { }
    public void visit(ConstDeclList ConstDeclList) { }
    public void visit(VarDeclListPart VarDeclListPart) { }
    public void visit(VarDeclList VarDeclList) { }
    public void visit(FormalParamList FormalParamList) { }
    public void visit(ConstVal ConstVal) { }
    public void visit(Expr Expr) { }
    public void visit(MethodTypeName MethodTypeName) { }
    public void visit(DesignatorStatement DesignatorStatement) { }
    public void visit(NumConstOp NumConstOp) { }
    public void visit(Statement Statement) { }
    public void visit(MethodDeclFP MethodDeclFP) { }
    public void visit(VarDecl VarDecl) { }
    public void visit(Type Type) { }
    public void visit(ConstDecl ConstDecl) { }
    public void visit(ErrorPart ErrorPart) { }
    public void visit(MethodDeclList MethodDeclList) { }
    public void visit(FormPars FormPars) { }
    public void visit(IdentExprList IdentExprList) { }
    public void visit(MulopPer MulopPer) { visit(); }
    public void visit(MulopDiv MulopDiv) { visit(); }
    public void visit(MulopMul MulopMul) { visit(); }
    public void visit(AddopMinus AddopMinus) { visit(); }
    public void visit(AddopPlus AddopPlus) { visit(); }
    public void visit(IdentExprListLsquare IdentExprListLsquare) { visit(); }
    public void visit(DesignatorC DesignatorC) { visit(); }
    public void visit(DesignatorArrayC DesignatorArrayC) { visit(); }
    public void visit(DesignatorExpr DesignatorExpr) { visit(); }
    public void visit(FactorNewActPars FactorNewActPars) { visit(); }
    public void visit(FactorExpr FactorExpr) { visit(); }
    public void visit(FactorBoolConst FactorBoolConst) { visit(); }
    public void visit(FactorCharConst FactorCharConst) { visit(); }
    public void visit(FactorNumConst FactorNumConst) { visit(); }
    public void visit(FactorDes FactorDes) { visit(); }
    public void visit(SingleTermC SingleTermC) { visit(); }
    public void visit(TermC TermC) { visit(); }
    public void visit(NoMinusOptional NoMinusOptional) { visit(); }
    public void visit(MinusOptional MinusOptional) { visit(); }
    public void visit(SingleExprc SingleExprc) { visit(); }
    public void visit(ExprC ExprC) { visit(); }
    public void visit(NoDesignatorOptList NoDesignatorOptList) { visit(); }
    public void visit(DesignatorOptListC DesignatorOptListC) { visit(); }
    public void visit(NoDesignatorOpt NoDesignatorOpt) { visit(); }
    public void visit(DesignatorOptC DesignatorOptC) { visit(); }
    public void visit(DLsquareC DLsquareC) { visit(); }
    public void visit(DesignatorStatementAssign DesignatorStatementAssign) { visit(); }
    public void visit(DesignatorStatementDec DesignatorStatementDec) { visit(); }
    public void visit(DesignatorStatementInc DesignatorStatementInc) { visit(); }
    public void visit(DesignatorStatementExpr DesignatorStatementExpr) { visit(); }
    public void visit(NoNumConstOp NoNumConstOp) { visit(); }
    public void visit(NumConstOpC NumConstOpC) { visit(); }
    public void visit(StatementDerived1 StatementDerived1) { visit(); }
    public void visit(PrintStm PrintStm) { visit(); }
    public void visit(ReadStm ReadStm) { visit(); }
    public void visit(Assignment Assignment) { visit(); }
    public void visit(NoStmt NoStmt) { visit(); }
    public void visit(Statements Statements) { visit(); }
    public void visit(FormalParamArrayDeclC FormalParamArrayDeclC) { visit(); }
    public void visit(FormalParamDeclC FormalParamDeclC) { visit(); }
    public void visit(NoFormalParamDecl NoFormalParamDecl) { visit(); }
    public void visit(FormalParamDecls FormalParamDecls) { visit(); }
    public void visit(NoFormParam NoFormParam) { visit(); }
    public void visit(FormParams FormParams) { visit(); }
    public void visit(MethodVoidType MethodVoidType) { visit(); }
    public void visit(MethodType MethodType) { visit(); }
    public void visit(MethodDeclFPC MethodDeclFPC) { visit(); }
    public void visit(MethodeDeclC MethodeDeclC) { visit(); }
    public void visit(NoMethodeDecls NoMethodeDecls) { visit(); }
    public void visit(MethodeDecls MethodeDecls) { visit(); }
    public void visit(TypeC TypeC) { visit(); }
    public void visit(ConstDeclC ConstDeclC) { visit(); }
    public void visit(BoolVal BoolVal) { visit(); }
    public void visit(CharVal CharVal) { visit(); }
    public void visit(NumVal NumVal) { visit(); }
    public void visit(NoAnotherConstDecl NoAnotherConstDecl) { visit(); }
    public void visit(AnotherConstDecl AnotherConstDecl) { visit(); }
    public void visit(VarDArrayC VarDArrayC) { visit(); }
    public void visit(VarDC VarDC) { visit(); }
    public void visit(VarDeclDerived1 VarDeclDerived1) { visit(); }
    public void visit(VarDeclC VarDeclC) { visit(); }
    public void visit(NoVarOnlyDeclarations NoVarOnlyDeclarations) { visit(); }
    public void visit(VarOnlyDeclarations VarOnlyDeclarations) { visit(); }
    public void visit(VarArrayDTwoC VarArrayDTwoC) { visit(); }
    public void visit(VarDTwoC VarDTwoC) { visit(); }
    public void visit(VarDeclListPartDerived1 VarDeclListPartDerived1) { visit(); }
    public void visit(VarDeclListPartC VarDeclListPartC) { visit(); }
    public void visit(NoAnotherVarDecl NoAnotherVarDecl) { visit(); }
    public void visit(AnotherVarDecl AnotherVarDecl) { visit(); }
    public void visit(NoDec NoDec) { visit(); }
    public void visit(ConstDecls ConstDecls) { visit(); }
    public void visit(VarDecls VarDecls) { visit(); }
    public void visit(ProgName ProgName) { visit(); }
    public void visit(Program Program) { visit(); }


    public void visit() { }
}
