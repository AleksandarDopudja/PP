// generated with ast extension for cup
// version 0.8
// 16/0/2023 13:16:44


package rs.ac.bg.etf.pp1.ast;

public class MethodeDeclC extends MethodeDecl {

    private MethodDeclFP MethodDeclFP;
    private StatementList StatementList;

    public MethodeDeclC (MethodDeclFP MethodDeclFP, StatementList StatementList) {
        this.MethodDeclFP=MethodDeclFP;
        if(MethodDeclFP!=null) MethodDeclFP.setParent(this);
        this.StatementList=StatementList;
        if(StatementList!=null) StatementList.setParent(this);
    }

    public MethodDeclFP getMethodDeclFP() {
        return MethodDeclFP;
    }

    public void setMethodDeclFP(MethodDeclFP MethodDeclFP) {
        this.MethodDeclFP=MethodDeclFP;
    }

    public StatementList getStatementList() {
        return StatementList;
    }

    public void setStatementList(StatementList StatementList) {
        this.StatementList=StatementList;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(MethodDeclFP!=null) MethodDeclFP.accept(visitor);
        if(StatementList!=null) StatementList.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(MethodDeclFP!=null) MethodDeclFP.traverseTopDown(visitor);
        if(StatementList!=null) StatementList.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(MethodDeclFP!=null) MethodDeclFP.traverseBottomUp(visitor);
        if(StatementList!=null) StatementList.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("MethodeDeclC(\n");

        if(MethodDeclFP!=null)
            buffer.append(MethodDeclFP.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(StatementList!=null)
            buffer.append(StatementList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [MethodeDeclC]");
        return buffer.toString();
    }
}
