// generated with ast extension for cup
// version 0.8
// 16/0/2023 13:16:44


package rs.ac.bg.etf.pp1.ast;

public class DesignatorOptListC extends DesignatorOptList {

    private DesignatorOptList DesignatorOptList;
    private DesignatorOpt DesignatorOpt;

    public DesignatorOptListC (DesignatorOptList DesignatorOptList, DesignatorOpt DesignatorOpt) {
        this.DesignatorOptList=DesignatorOptList;
        if(DesignatorOptList!=null) DesignatorOptList.setParent(this);
        this.DesignatorOpt=DesignatorOpt;
        if(DesignatorOpt!=null) DesignatorOpt.setParent(this);
    }

    public DesignatorOptList getDesignatorOptList() {
        return DesignatorOptList;
    }

    public void setDesignatorOptList(DesignatorOptList DesignatorOptList) {
        this.DesignatorOptList=DesignatorOptList;
    }

    public DesignatorOpt getDesignatorOpt() {
        return DesignatorOpt;
    }

    public void setDesignatorOpt(DesignatorOpt DesignatorOpt) {
        this.DesignatorOpt=DesignatorOpt;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(DesignatorOptList!=null) DesignatorOptList.accept(visitor);
        if(DesignatorOpt!=null) DesignatorOpt.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(DesignatorOptList!=null) DesignatorOptList.traverseTopDown(visitor);
        if(DesignatorOpt!=null) DesignatorOpt.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(DesignatorOptList!=null) DesignatorOptList.traverseBottomUp(visitor);
        if(DesignatorOpt!=null) DesignatorOpt.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("DesignatorOptListC(\n");

        if(DesignatorOptList!=null)
            buffer.append(DesignatorOptList.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(DesignatorOpt!=null)
            buffer.append(DesignatorOpt.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [DesignatorOptListC]");
        return buffer.toString();
    }
}
